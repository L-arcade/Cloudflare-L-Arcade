REN V3 — BAMBOO PATH COMBAT BUILD

Separate experimental real-3D branch. L-Arcade v451 is not modified.

V3 additions:
- Two-hit sword combo using supplied inward/outward slash animations
- 3D enemy encounter and enemy health state
- Block interaction and dodge movement
- River and wooden bridge
- Bamboo corridor
- Stone stair shrine approach and torii destination
- Drifting leaf atmosphere
- Third-person free orbit camera
- Existing experimental Mixamo-to-CC_Base runtime retargeting retained

Controls: WASD move, Shift run, Space dodge, J attack, K block, Q draw/sheath, mouse/pointer drag camera.

Note: Requires internet on first launch for Three.js modules from jsDelivr. This remains a development prototype; animation retargeting and Android performance still require device testing.
